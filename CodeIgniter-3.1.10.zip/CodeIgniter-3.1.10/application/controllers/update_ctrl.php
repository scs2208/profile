<?php
    class update_ctrl extends CI_Controller{
        public function __construct(){
            parent::__construct();
            $this->load->model('update_model');
        }
        public function reg_id() {
            $id = $this->uri->segment(3);
            $data['registrations'] = $this->update_model->show_regs();
            $data['single_registration'] = $this->update_model->show_reg_id($id);
            
          
            $this->load->view('update_view', $data);
          
        }
        public function reg_id1() {
            $id= $this->input->post('tid');
            $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'Address' => $this->input->post('Address'),
            'tp_no' => $this->input->post('tp_no'),
            'attendence' => $this->input->post('attendence'),
            'salary' => $this->input->post('salary'),
            
            );
            $this->update_model->reg_id1($id,$data);
            $this->reg_id();
        }
    }
?>